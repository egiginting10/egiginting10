class Node:
    def __init__(self, data, priority):
        self._data = data
        self._priority = priority # 1 (tertinggi), 2, 3, 4, ...
        self._next = None

class PriorityQueueUnsorted:
    def __init__(self):
        self._head = None
        self._tail = None
        self._size = 0
    def is_empty(self):
        if self._size == 0:
            return True
        else:
            return False
    def __len__(self):
        return self._size
    def print_all(self):
        if self.is_empty() == True:
            print('Priority Queue is empty')
        else:
            bantu = self._head
            while bantu != None:
                print('(', bantu._data, ',', bantu._priority, ')', end=' ')
                bantu = bantu._next
        print()
    def add(self, data, priority):
        baru = Node(data, priority)
        if self.is_empty(): 
            self._head = baru
            self._tail = baru
        else: 
            self._tail._next = baru
            self._tail = baru
        self._size = self._size + 1
    def remove(self): 
        if self.is_empty() == False:
            if self._size == 1:
                bantu = self._head
                self._head = None
                self._tail = None
                del bantu
            else:
                min_priority = self._head._priority
             
                hapus = self._head
                while hapus != None:
                    if hapus._priority < min_priority:
                        min_priority = hapus._priority
                    hapus = hapus._next
               
                hapus = self._head
                while hapus._priority != min_priority:
                    hapus = hapus._next
               
                if hapus == self._head:
        
                    self._head = self._head._next
                    del hapus
                else:
                    bantu = self._head
                    while bantu._next != hapus:
                        bantu = bantu._next
                    bantu._next = hapus._next
                    del hapus
                    self._tail = self._head
                    while self._tail._next != None:
                        self._tail = self._tail._next
            self._size = self._size - 1
    def peek(self):
        if self.is_empty() == True:
            return None
        else:
            if self._size == 1:
                return tuple([self._head._data, self._head._priority])
            else:
                min_priority = self._head._priority
                bantu = self._head

                while bantu != None:
                    if bantu._priority < min_priority:
                        min_priority = bantu._priority
                    bantu = bantu._next
                bantu = self._head
                while bantu._priority != min_priority:
                    bantu = bantu._next
                return tuple([bantu._data, bantu._priority])
    def remove_priority(self, priority):
        if self.is_empty() == False:
            if self._size == 1:
                bantu = self._head
                self._head = None
                self._tail = None
                del bantu
            else:
                hapus = self._head
                while hapus._priority != priority:
                    hapus = hapus._next
                bantu = self._head
                while bantu._next != hapus:
                    bantu = bantu._next
                bantu._next = hapus._next
                del hapus
                self._tail = self._head
                while self._tail._next != None:
                    self._tail = self._tail._next
                self._size = self._size - 1
    
unsorted = PriorityQueueUnsorted()
unsorted.add("Innova", 5)
unsorted.add("Avanza", 1)
unsorted.add("Porsche", 3)
unsorted.add("GTR", 4)
unsorted.print_all()

data, priority = unsorted.peek()
print(data)
print(priority)
print()

unsorted.remove()
unsorted.print_all()
print()

unsorted.add("Ayla", 2)
unsorted.add("Mazda", 1)
unsorted.add("Agya", 3)
unsorted.add("Brio", 2)
unsorted.print_all()
print()

unsorted.remove_priority(2)
unsorted.print_all()