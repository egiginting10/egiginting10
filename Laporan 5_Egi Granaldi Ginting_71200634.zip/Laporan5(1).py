class PriorityQueueList:
    def __init__(self):
        self._data = []
        self._cetak = []
    def __len__(self):
        return len(self._data)
    def isEmpty(self):
        return len(self._data) == 0
    def add(self, priority, data):
        self._data.append((priority, data))
    def remove(self):
        if self.isEmpty():
            print("Priority Queue Kosong!")
        min = 1000
        index = 0
        for i in range(len(self._data)):
            if self._data[i][0] < min:
                min = self._data[i][0]
                index = i
        item = self._data[index]
        del self._data[index]
        return item
    def peek(self):
        min = 100
        data = ''
        index = 0
        for i in range(len(self._data)):
            if self._data[i][0] < min:
                min = self._data[i][0]
                data = self._data[i][1]
                index = i
        print(min, data)
    def print(self):
        for i in range(len(self._data)):
            self._cetak.append(self._data[i])
        self._cetak.sort(reverse=True)
        while self._cetak:
            next = self._cetak.pop()
            print(next)
    def removePriority(self, prio):
        if self.isEmpty():
            print("Priority Queue Kosong!")
        min = 100
        index = []
        for i in range(len(self._data)):
            if self._data[i][0] == prio:
                index.append(self._data[i])
        for j in index:
            self._data.remove(j)

qlist = PriorityQueueList()
qlist.add(4, "Lamborghini")
qlist.add(3, "Ferrari")
qlist.add(1, "Porsche")
qlist.add(2, "GTR")
qlist.print()
print()

qlist.remove() 
qlist.print()
print()

qlist.peek() 
print()


qlist.removePriority(1)
qlist.print()
