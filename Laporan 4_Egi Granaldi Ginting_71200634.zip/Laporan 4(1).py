class Queue:
    Default_Capacity=8
    def _init_(self):
        self._namakomp=[None]*Queue.Default_Capacity
        self._namafile=[None]*Queue.Default_Capacity
        self._jumlahhalaman=[None]*Queue.Default_Capacity
        self._size=0
        self._front=0
    def _len_(self):
        return self._size
    def is_empty(self):
        return self._size==0
    def dequeue(self):
        if self.is_empty():
            print("Kosong")
        else:
            answer=self._namakomp[self._front]
            answer1=self._namafile[self._front]
            answer2=self._jumlahhalaman[self._front]
            self._namakomp[self._front]=None
            self._namafile[self._front]=None
            self._jumlahhalaman[self._front]=None
            self._front=(self._front+1)%len(self._namakomp)
            self._size-=1
            print("Yang telah selesai tercetak:")
            print(answer,answer1,answer2)
    def enqueue(self,namakomp,namafile,jumlahhalaman):
        if self._size==len(self._namakomp):
            print("Terlalu banyak antrian. Mohon ditunggu")
        else:
            avail1=(self._front+self._size)%len(self._namakomp)
            self._namakomp[avail1]=namakomp
            avail2=(self._front+self._size)%len(self._namafile)
            self._namafile[avail2]=namafile
            avail3=(self._front+self._size)%len(self._jumlahhalaman)
            self._jumlahhalaman[avail3]=jumlahhalaman
            self._size+=1
    def printAll(self):
        if self.is_empty():
            print("Kosong!")
        else:
            count=0
            print("Seluruh antrian printer:")
            for i in range(self._front,(self._front+self._size)):
                print("Nama komputer:",self._namakomp[i%len(self._namakomp)])
                print("Nama file:",self._namafile[i%len(self._namakomp)])
                print("Jumlah halaman:",self._jumlahhalaman[i%len(self._namakomp)])
                count+=self._jumlahhalaman[i]
                 print("Total seluruh halaman:", count)
 
myqueue=Queue()
myqueue.enqueue("Komp1","strukdat1.pdf",1)
myqueue.enqueue("Komp2","strukdat2.pdf",2)
myqueue.enqueue("Komp3","strukdat3.pdf",3)
myqueue.enqueue("Komp4","strukdat4.pdf",4)
myqueue.enqueue("Komp5","strukdat5.pdf",5)
myqueue.enqueue("Komp6","strukdat6.pdf",6)
myqueue.enqueue("Komp7","strukdat7.pdf",7)
myqueue.enqueue("Komp8","strukdat8.pdf",8)
myqueue.enqueue("Komp9","strukdat9.pdf",9)
myqueue.printAll()
myqueue.dequeue()
myqueue.printAll()