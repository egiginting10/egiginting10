class Queue:       
    DEFAULT_CAPACITY = 5
    def _init_(self):
        self._data = [None] * Queue.DEFAULT_CAPACITY
        self._size = 0
        self._front = 0
 
    def _len_(self):
        return self._size
 
    def is_empty(self):
        return self._size == 0
 
    def first(self):     
        if self.is_empty():
            print("Empty")
            return None
        else:
            return self._data[self._front]
 
    def enqueue(self, e):    
        if self._size == Queue.DEFAULT_CAPACITY:   
            self.resize(2*len(self._data)) 
            self.DEFAULT_CAPACITY = 2 * self.DEFAULT_CAPACITY 
        avail = (self._front + self._size) % len(self._data) 
        self._data[avail] = e
        self._size += 1
 
    def dequeue(self):
        if self.is_empty():
            print("Kosong!")
            return None
        else:
            answer = self._data[self._front]
            self._data[self._front] = None 
            self._front = (self._front + 1) % len(self._data)
            self._size -= 1
            return answer
 
    def printAll(self):
        if self._size > 0:
            for i in range(self._front,self._size+self._front):
                print(self._data[i])
        else:
            print("Empty!")
        print("\n")
 
def antrian(daftar):
    kasir1 = Queue()
    kasir2 = Queue()
    kasir3 = Queue()

    if len(daftar) <= 5: 
        for i in daftar[:5]:
            kasir1.enqueue(i)
        print(f'Kasir 1:')
        kasir1.printAll()
    elif len(daftar) <= 10: 
        for i in daftar[:5]: 
            kasir1.enqueue(i)
        print(f'Kasir 1:')
        kasir1.printAll()
        for i in daftar[5:10]: 
            kasir2.enqueue(i)
        print(f'Kasir 2:')
        kasir2.printAll()
    elif len(daftar) <= 15: 
        for i in daftar[:5]: 
            kasir1.enqueue(i)
        print(f'Kasir 1:')
        kasir1.printAll()
        for i in daftar[5:10]: 
            kasir2.enqueue(i)
        print(f'Kasir 2:')
        kasir2.printAll()
        for i in daftar[10:15]:
            kasir3.enqueue(i)
        print(f'Kasir 3:')
        kasir3.printAll()

    else:
        print("Kasir Full!, Tunggu beberapa saat")
 
list_antrian = ["Egi","Hennoch","Tiur","Kesya","Ignes","Silvi","Ega","Hannoch","Teli","Ines","Jebe","Nana","Natu","Nina","Nunu","Siti"]
antrian(list_antrian)