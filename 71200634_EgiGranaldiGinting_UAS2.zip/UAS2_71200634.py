class Graph:
    def __init__(self):
        self._data = {}
    def addVertex(self, key):
        if key not in self._data:
            self._data[key] = set()
    def vertex(self):
        for key, value in self._data.items():
            print(key, end = ' ')
        print()
    def addEdge(self, x, y):
        if x in self._data and y in self._data:
            self._data[x].add(y)
            self._data[y].add(x)
            
    def findPath(self, x, y):
        visited = []
        self.dfs(x, y, visited)
    def BFS(self, s):
        visited = [False] * (max(self.graph) + 1)
        queue = []
        queue.append(s)
        visited[s] = True
        while queue:
            s = queue.pop(0)
            print (s, end = " ")
            for i in self.graph[s]:
                if visited[i] == False:
                    queue.append(i)
                    visited[i] = True
    def edge(self):
        listEdge = set()
        for key, value in self._data.items():
            for item in self._data[key]:
                if key+item not in listEdge and item+key not in listEdge:
                    listEdge.add(key+item)
        for item in listEdge:
            print(item, end = ' ')
        print()
        
graph = Graph()
graph.addVertex('1')
graph.addVertex('2')
graph.addVertex('3')
graph.addVertex('4')
graph.addVertex('5')
graph.addVertex('6')
graph.addVertex('7')    
graph.addEdge(1, 2)
graph.addEdge(1, 3)
graph.addEdge(1, 4)
graph.addEdge(2, 4)
graph.addEdge(3, 4)
graph.addEdge(4, 5)
graph.addEdge(5, 6)
graph.addEdge(6, 7)
graph.vertex()
graph.edge()