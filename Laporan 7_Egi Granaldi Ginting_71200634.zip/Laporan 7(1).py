class bukuTelepon:
    def __init__(self):
        self.size = 8
        self.map = [None] * self.size
    
    def _probing(self, key):
        index = 1
        while index < self.size:
            probeHash = self._quadraticProbing(key, index)
            index += 1
            if (self.map[probeHash] is None) or (self.map[probeHash]=='none'):
                return probeHash
        index = 1
        while index < self.size:
            probeHash = self._linearProbing(key, index)
            index += 1
            if (self.map[probeHash] is None) or (self.map[probeHash]=='none'):
                return probeHash
        return None

    def _getHash(self, key):
        hash = 0
        for num in key:
            hash += int(num)
        return hash % self.size

    def _quadraticProbing(self, key, index):
        return (self._getHash(key)+index**2) % self.size

    
    def _linearProbing(self, key, index):
        return (self._getHash(key)+index) % self.size
    
    def add(self, key, value):
        key_hash = self._getHash(key)
        key_value = [key, value]
        if self.map[key_hash] is None:
            self.map[key_hash] = list(key_value)
            return True
        else:
            key_hash = self._probing(key)
            if key_hash is None:
                print("Slot sudah penuh!")
                return False
        self.map[key_hash] = list(key_value)
        return True

    def getName(self, key):
        key_hash = self._getHash(key)
        if self.map[key_hash] is not None:
            if(self.map[key_hash][0] == key):
                    return self.map[key_hash][1]
            else:
                for index in range(1,self.size+1):
                    key_hash = self._quadraticProbing(key,index)
                    if self.map[key_hash] is not None:
                        if(self.map[key_hash][0] == key):
                            return self.map[key_hash][1]

                for index in range(1,self.size+1):
                    key_hash = self._linearProbing(key,index)
                    if self.map[key_hash] is not None:
                        if(self.map[key_hash][0] == key):
                            return self.map[key_hash][1]
        print("Data Buku Telepon %s tidak ditemukan" %key)
        return 'Tidak ada'

    def delete(self, key):
        key_hash = self._getHash(key)
        if self.map[key_hash] is not None:
            if(self.map[key_hash][0] == key):
                self.map[key_hash] = 'Sudah Dihapus' 
                print("deleting ", key)
                return True
            else:
                for index in range(1,self.size+1):
                    key_hash = self._quadraticProbing(key,index)
                    if self.map[key_hash] is not None:
                        if(self.map[key_hash][0] == key):
                            self.map[key_hash] = 'none' 
                            print("deleting ", key)
                            return True

                for index in range(1,self.size+1):
                    key_hash = self._linearProbing(key,index)
                    if self.map[key_hash] is not None:
                        if(self.map[key_hash][0] == key):
                            self.map[key_hash] = 'none' 
                            print("deleting ", key)
                            return True
        print("Data Buku Telepon %s tidak ditemukan" %key)
        return(key,'= none')
 
    def printAll(self):
        print('---Data Buku Telepon----')
        for item in self.map:
            if item is not None:
                print(str(item))
        print()

hashing = bukuTelepon()
hashing.add('081275663374','Dian')
hashing.add('082167665400','Dimas')
hashing.add('082167665420','Egi') 
hashing.add('081363665130','Hennoch')   
hashing.add('082164114312','Tiur')
hashing.add('082165225987','Ignes') 
hashing.add('082165575660','Jebe') 
hashing.add('089612430078','Ines') 
hashing.add('089613738163','Caca') 
hashing.printAll()
hashing.delete('081363665130') 
hashing.delete('082165575660') 
hashing.delete('082165575000') 
hashing.printAll()
hashing.add('085765811220','Jessica') 
hashing.printAll()
print('082165225987 = ' + hashing.getName('082165225987')) 
print('082167665420 = ' + hashing.getName('082167665420')) 
print('082167665000 = ' + hashing.getName('082167665000')) 