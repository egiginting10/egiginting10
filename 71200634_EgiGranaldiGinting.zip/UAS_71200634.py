#Egi Granaldi Ginting
#71200634

class QueueSorted:
    def __init__(self):
        self.element = []
        self.count = {}
    def len(self):
        return len(self.element)
    def isEmpty(self):
        return len(self.element) == 0                       
    def compute(self, insert):
        place = insert[1]
        if place not in self.count:
            self.count[place] = 1
        else:
            self.count[place] = self.count[place] + 1   
    def printAll(self):
        for i in self.element:
            print(i, end=" ")
        print()

    def delete(self,insert):
        place = insert[1]
        self.count[place] = self.count[place] - 1

    def remove(self):
        if self.isEmpty() == False:
            insert = self.element.pop(0)
            self.delete(insert)
        else:
            print("Kosong")

    def remove_priority(self, priority):
        if priority not in self.count and self.count[priority] == 0:
            print("Data tidak ditemukan")
        else:
            for j in range (self.count[priority]):
                for i in range(len(self.element)):
                    if self.element[i][1] == priority:
                        del self.element[i]
                        insert = (None, priority)
                        self.delete(insert)
                        break

    def add(self, element, priority):
        insert = (element, priority)
        if self.isEmpty() == False:
            e = self.element
            for i in range(len(self.element)):
                if self.element[i][1] > priority:
                    self.element = e[:i]
                    self.element.append(insert)
                    self.element.extend(e[i:])
                    break
                else:
                    if i == len(self.element) - 1:
                        self.element.append(insert)
        else:
            self.element.append(insert)
        self.compute(insert)

    def peek(self):
        insert = self.element[0]
        return insert
    
    def hitung(self):
        for i in self.element:
            jumlah = sum(i)
        print("Pertambahan nilai = ", jumlah, end = " ")

           
pqsorted = QueueSorted()
pqsorted.add(4, 5)
pqsorted.add(6, 1)
pqsorted.add(3, 3)
pqsorted.add(1, 4)
pqsorted.printAll()
pqsorted.hitung()