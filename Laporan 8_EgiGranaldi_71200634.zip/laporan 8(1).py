class Node:
    def __init__ (self, data, parent):
        self._data = data
        self._children = []
        self._parent = parent

    def addChild(self, data):
        self._children.append(data)

    def operator(self):
        return self._data

    def parent(self):
        return self._parent

    def children(self):
        return self._children

    def isRoot(self):
        return self._parent is None

    def isExternal(self):
        return len(self._children) == 0


root =Node(100,None)
a = Node(15,root)
b = Node(23,root)
c = Node(20,a)
d = Node(78,a)
e = Node(24,b)
f = Node(42,c)
g = Node(51,c)
h = Node(76,d)
i = Node(12,d)
j = Node(15,d)
k = Node(8,e)
l = Node(33,e)
a.addChild(c)
a.addChild(d)
b.addChild(e)
c.addChild(f)
c.addChild(g)
d.addChild(h)
d.addChild(i)
d.addChild(j)
e.addChild(k)
e.addChild(l)
root.addChild(a)
root.addChild(b)


print(root.operator())
print("anak dari node 100 adalah :")
for i in root.children():
    print(i.operator(),end=' ')
print("")
print("anak dari node 15 adalah :")
for i in a.children():
    print(i.operator(),end=' ')
print("")
print("anak dari node 23 adalah :")
for i in b.children():
    print(i.operator(),end=' ')
print(" ")
print("anak dari node 20 adalah :")
for i in c.children():
    print(i.operator(),end=' ')
print("")
print("anak dari node 78 adalah :")
for i in d.children():
    print(i.operator(),end=' ')
print("")
print("anak dari node 24 adalah :")
for i in e.children():
    print(i.operator(),end=' ')
print(" ")