class Node_Tree:
    def __init__(self, data, parent):
        self._data = data
        self._parent = parent
        self._child = []
        
    def insert_Child(self, data):
        self._child.append(data)
            
    def isExternal(self):
        return len(self._child) == 0
 
    
    def child(self):
        return self._child

    def get_data(self):
        return self._data

    def preorder(self,node):  
        if node is not None:
            print(node.get_data(), end = ' ')
            for data_child in node.child():
                self.preorder(data_child)       

    def sum(self):
        sum_data = 0
        if (self.isExternal() == False):
            for child_data in self._child:
                sum_data += child_data.sum()
        return sum_data + self._data

root = Node_Tree(100, None)
node_a = Node_Tree(15, root)
node_b = Node_Tree(23, root)
node_c = Node_Tree(20, node_a)
node_d = Node_Tree(78, node_a)
node_e = Node_Tree(24, node_b)
node_f = Node_Tree(42, node_c)
node_g = Node_Tree(51, node_c)
node_h = Node_Tree(76, node_d)
node_i = Node_Tree(12, node_d)
node_j = Node_Tree(15, node_d)
node_k = Node_Tree(8, node_e)
node_l = Node_Tree(33, node_e)
root.insert_Child(node_a)
root.insert_Child(node_b)
node_a.insert_Child(node_c)
node_a.insert_Child(node_d)
node_b.insert_Child(node_e)
node_c.insert_Child(node_f)
node_c.insert_Child(node_g)
node_d.insert_Child(node_h)
node_d.insert_Child(node_i)
node_d.insert_Child(node_j)
node_e.insert_Child(node_k)
node_e.insert_Child(node_l)
print('='*8+' Data Tree '+'='*8)
root.preorder(root)
print('\nTotal dari tree:',root.sum())
print('Total dari tree:',node_d.sum())
print('Total dari tree:',node_i.sum())