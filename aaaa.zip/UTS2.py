#Egi granaldi ginting
#71200634

class Stack : 
    def _init_(self):
         self.item = []
         self._element = element
         self._next = n
    def _len_ (self) : 
        return len(self._data)
    def isEmpty(self):
         return self.item == 0
    def top(self) :
        if self.isEmpty() :
            print("Kosong")
        return self._item[1]
    def pop(self):
         return self.item.pop()
    def push(self, a):
         self.item.append(a)
    def peek(self):
         return self.item[len(self.item)-1]
    def size(self):
         return len(self.item)
    def operate(self,n):
        if n<=len(self.item):
            hasil = 1
            urutan = 0
            for i in range(n):
                urutan += 1
                urt = i - urutan
                hasil *= self.item[urt]
                self.item.pop()
            self.item.append(hasil)
        else:
            print('operasi tidak valid')
       
    def print(self):
        if self.isEmpty() :
            print("Stack Kosong!")
        else :
            for i in range(len(self.item)-1,-1,-1) :
                print (self.item[i],end = ",")
            print("")
_name_ = Stack
    

if _name_ == "_main_":
    stack = Stack()
    stack.push(20)
    stack.push(30)
    stack.push(40)
    stack.push(50)
    stack.print() 
    stack.operate(2)
    stack.print() 
    stack.operate(10) 
    stack.print() 
    stack.operate(3)
    stack.print()