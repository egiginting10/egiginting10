class Node:
    def _init_(self, e, n, p):
        self._element=e
        self._next=n
        self._prev=p

class DLLNC:
    def _init_(self):
        self._head=None
        self._tail=None
        self._size=0
    
    def _len_(self):
        return self._size
    
    def isEmpty(self):
        return self._size==0
    
    def addFirst(self, e):
        baru=Node(e, None, None)
        if self.isEmpty() == True:
            self._head = baru
            self._tail = baru
            self._head._next = None
            self._head._prev = None
            self._tail._next = None
            self._tail._prev = None
        else:
            self._head._prev=baru
            baru._next=self._head
            self._head=baru
        self._size += 1
    print("Data masuk head")
    
    def addLast(self, e,n):
        baru=Node(e, None, None)
        if self.isEmpty() == True:
            self._head = baru
            self._tail = baru
            self._head._next = None
            self._head._prev = None
            self._tail._next = None
            self._tail._prev = None
        else:
            baru._prev=self._tail
            self._tail._next=baru
            self._tail=baru
        self._size += 1
    print("Data masuk tail")

    def insertAfter(self, e, n):
        baru=Node(e, None, None)
        simpan=self._head
        while simpan._element!=n:
            if simpan._next!=None:
                simpan=simpan._next
            else:
                print('Data tidak ditemukan, element tidak ditambahkan!')
                return 0
        if simpan==self._tail and simpan._next==None:
            baru._prev=simpan
            simpan._next=baru
            self._tail=baru
            simpan._next=baru
        else:
            baru._next=simpan._next
            baru._prev=simpan
            simpan._next._prev=baru
            simpan._next=baru

    def insertBefore(self, e, n):
        baru=Node(e, None, None)
        simpan=self._head
        while simpan._element!=n:
            if simpan._next!=None:
                simpan=simpan._next
            else:
                print('Data tidak ditemukan, element tidak ditambahkan!')
                return 0
        if simpan == self._head and simpan._prev==None:
            baru._next=simpan
            simpan._prev=baru
            self._head=baru
        else:
            baru._next=simpan
            baru._prev=simpan._prev
            simpan._prev._next=baru
            simpan._prev=baru

    def delete(self, e):
        if self.isEmpty()==False:
            simpan=self._head
            if simpan._element==e:
                self._head=simpan._next
                simpan._next._prev=None
                print(simpan._element, 'terhapus!')
                del simpan
                self._size-=1
            while simpan._element!=e:
                if simpan._next!=None:
                    simpan=simpan._next
                else:
                    print('Data tidak ditemukan!')
                    return 0
            if simpan==self._tail and simpan._next==None:
                self._tail=simpan._prev
                simpan._prev=None
                self._tail._next=None
                print(simpan._element,'terhapus!')
                del simpan
                self._size-=1
            else:
                simpan._prev._next=simpan._next
                simpan._next._prev=simpan._prev
                print(simpan._element,'terhapus!')
                del simpan
                self._size-=1

    def deleteFirst(self):
        if self.isEmpty() == False:
            if self._head._next==None:
                d=self._head._element
                self._head=None
                self._tail=None
            else:
                hapus=self._head
                d=hapus._element
                self._head=hapus._next
                del hapus
                self._head._prev=None
            self._size-=1
            print(d,"terhapus!")

    def deleteLast(self):
        if self.isEmpty() == False:
            if self._head._next==None:
                d=self._head._element
                self._head=None
                self._tail=None
            else:
                hapus=self._tail
                self._tail=self._tail._prev
                d=hapus._element
                del hapus
                self._tail._next = None
            self._size-=1
            print(d,"terhapus!")
    
    def printAllForward(self):
        if self.isEmpty() == False:
            cetak=self._head
            while(cetak != None):
                print(cetak._element,end=' ')
                cetak = cetak._next
        else:
            print('Kosong')
        print('')
    
    def printAllBackward(self):
        if self.isEmpty()==False:
            simpan=self._tail
            while simpan!=None:
                print(simpan._element, end=' ')
                simpan=simpan._prev
        else:
            print('Kosong!')
        print('')
  

mydllnc=DLLNC()
mydllnc.addFirst('tiur')
mydllnc.addFirst('tiur') 
mydllnc.addLast('Hennoch') 
mydllnc.deleteFirst() 
mydllnc.deleteLast() 
mydllnc.printAllForward()
mydllnc.deleteFirst()
mydllnc.printAllForward()
mydllnc.deleteLast()
mydllnc.printAllForward()