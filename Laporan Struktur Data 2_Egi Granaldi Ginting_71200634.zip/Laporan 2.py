class Node:
    def __init__(self,element,n):
        self._element = element
        self._next = n
class SLLNC:
    def __init__(self):
        self._head=None
        self._tail=None
        self._size = 0

    def isEmpty(self):
        return self._size == 0

    def __len__(self):
        return self._size

    def addFirst(self,e):
        baru = Node(e, None)
        if self.isEmpty()==True:
            self._head = baru

            self._tail = baru
            self._tail._next = None
        else:
          baru._next = self._head         
          self._head = baru
        self._size += 1
        print("Data masuk head")
    
    def addLast(self,e):
        baru = Node(e, None)
        if self._tail == None:
            self._head = baru
            self._tail = baru
            self._tail._next = None
        else:
            self._tail._next = baru
            self._tail = baru
        self._size += 1
        print("Data masuk tail")
        
    def insertAfter(self, e, n):
        baru=Node(e, None, None)
        simpan=self._head
        while simpan._element!=n:
            if simpan._next!=None:
                simpan=simpan._next
            else:
                print('Data tidak ditemukan, element tidak ditambahkan!')
                return 0
        if simpan==self._tail and simpan._next==None:
            baru._prev=simpan
            simpan._next=baru
            self._tail=baru
            simpan._next=baru
        else:
            baru._next=simpan._next
            baru._prev=simpan
            simpan._next._prev=baru
            simpan._next=baru

    def insertBefore(self, e, n):
        baru=Node(e, None, None)
        simpan=self._head
        while simpan._element!=n:
            if simpan._next!=None:
                simpan=simpan._next
            else:
                print('Data tidak ditemukan, element tidak ditambahkan!')
                return 0
        if simpan == self._head and simpan._prev==None:
            baru._next=simpan
            simpan._prev=baru
            self._head=baru
        else:
            baru._next=simpan
            baru._prev=simpan._prev
            simpan._prev._next=baru
            simpan._prev=baru

    def deleteFirst(self):
        if self.isEmpty()==False:
            d = ""
            if self._head._next==None:
                d = self._head._element
                self._head=None
                self._tail=None
            else:
                hapus = self._head
                d = hapus._element
                self._head = self._head._next
                hapus._next=None
                del hapus
            self._size -= 1
            print(d," dihapus")
        else:
            print("None")
            

    def deleteLast(self):
        if self.isEmpty() == False:
            d = None
            tolong = self._head
            if(self._head != self._tail):
                while tolong._next != self._tail:
                    tolong = tolong._next
                hapus = self._tail
                self._tail = tolong
                d = hapus._element
                del hapus
                self._tail._next = None
            else:
                d = self._tail._element
                self._head=tail=None
            self._size -= 1
            print(d, " dihapus")
        else:
            print("None")

    def printAllForward(self):
        if self.isEmpty()==False:
            tolong = self._head
            while(tolong!=None):
                print(tolong._element," ",end='')
                tolong = tolong._next
                print()
        else:
            print("None")

    def printAllBackward(self):
        if self.isEmpty()==False:
            simpan=self._tail
            while simpan!=None:
                print(simpan._element, end=' ')
                simpan=simpan._prev
        else:
            print('Kosong!')
        print('')

mysllnc = SLLNC()
mysllnc.addFirst("egi")
mysllnc.addFirst("tiur")
mysllnc.addFirst("hennoch")
mysllnc.addLast("septiani")
mysllnc.addLast("saragih")
mysllnc.printAllForward()
mysllnc.deleteFirst()
mysllnc.printAllForward()
mysllnc.deleteLast()
mysllnc.printAllForward()
