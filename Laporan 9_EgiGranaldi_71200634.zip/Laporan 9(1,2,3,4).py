class Node:
    def __init__(self, data, parent):
        self._data = data
        self._parent = parent
        self._left = None
        self._left2 = None
        self._right = None
        self._right2 = None
    def insert_ganjil(self,data):
        if self.left() is None and data < self.operator():
            if self.left() is None:
                self._left = Node(data, self)
            else:
                self.left().insert_ganjil(data)
        elif data > self.operator():
            if self.left2() is None:
                self._left2 = Node(data, self)
            else:
                self.left2().insert_ganjil(data)
        else:
            return False 
        return True 

    def insert_genap(self,data):
        if self.right() is None and data < self.operator():
            if self.right() is None:
                self._right = Node(data, self)
            else:
                self.right().insert_genap(data)
        elif data > self.operator():
            if self.right2() is None:
                self._right2 = Node(data, self)
            else:
                self.right2().insert_genap(data)
        else:
            return False 
        return True 

    def insert(self, data):
        if data % 2 != 0:
            return self.insert_ganjil(data)
        elif data % 2 == 0:
            return self.insert_genap(data)

    def operator(self):
        return self._data

    def parent(self):
        return self._parent

    def left(self):
        return self._left

    def left2(self):
        return self._left2

    def right(self):
        return self._right

    def right2(self):
        return self._right2
        
class BinarySearchTree:
    def __init__(self):
        self._root = 0

    def add(self, data):
        if self._root == 0:
            self._root = Node(0, self)
            self._root.insert(data)
        else:
            self._root.insert(data)

    def node_kiri(self):
        print("Nilai Data kiri yaitu :",end="")
        self.inorder_kiri(self._root)
    def inorder_kiri(self, node):
        if node is not None:
            self.inorder_kiri(node.left())
            print(node.operator(), end = ' ')
            self.inorder_kiri(node.left2())
    
    def node_kanan(self):
        print("Nilai Data kanan yaitu:",end="")
        self.inorder_kanan(self._root)
    def inorder_kanan(self, node):
        if node is not None:
            self.inorder_kanan(node.right())
            print(node.operator(), end = ' ')
            self.inorder_kanan(node.right2())
    

bst = BinarySearchTree()
data = [5, 4, 3, 9, 8, 6, 7, 11,10]
for i in data:
    bst.add(i)
bst.node_kiri()
print()
bst.node_kanan()
