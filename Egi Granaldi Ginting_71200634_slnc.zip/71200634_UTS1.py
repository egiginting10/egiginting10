#Egi Granaldi Ginting
#71200634
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
class SingleLinkedListNonCircular:
    def __init__(self):
        self.size = 0
        self.head = None
        self.tail = None
    
    def insert(self, new_data):
        node_insert = Node(new_data)


        if self.head == None:
            self.head = node_insert

        elif self.head.data <= node_insert.data :
            node_insert.next = self.head
            self.head = node_insert
            self.size +=1

        else:
            penanda = self.head
            while penanda.next and node_insert.data < penanda.next.data:
                penanda = penanda.next
            node_insert.next = penanda.next
            penanda.next = node_insert
            self.size +=1
            
    def print(self):
        if self.size == 0:
            print('Linked List is empty')
        else:
            print('There are ', self.size, ' data: ')

            helper = self.head
            while helper != None:
                print(helper.data, end=' ')
                helper = helper.next
            print()
   
    def delete_head(self):
        if self.size == 0:
            return False
        elif self.size == 1:
            helper = self.head
            self.head = None
            self.tail = None
            del helper
            self.size = self.size - 1
            return True
        else:
            helper = self.head
            self.head = self.head.next
            del helper
            self.size = self.size - 1
            return True
   
    def delete_tail(self):
        if self.size == 0:
            return False
        elif self.size == 1:
            delete = self.tail
            self.tail = None
            self.head = None
            del delete
            self.size = self.size - 1
        else:
            helper = self.head
            while helper.next != self.tail:
                helper = helper.next
            delete = self.tail
            self.tail = helper
            self.tail.next = None
            del delete

            self.size = self.size - 1

slnc = SingleLinkedListNonCircular()
slnc.insert(40)
slnc.insert(10)
slnc.print()
slnc.insert(5)
slnc.insert(15)
slnc.print()
slnc.delete_head()
slnc.print() 
slnc.delete_tail()
slnc.print() 
slnc.insert(13)
slnc.insert(12)
slnc.insert(14)
slnc.print()