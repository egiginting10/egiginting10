import time
import random
import sys
sys.setrecursionlimit(10000)
count = 0

def random_data (limit):
    randomlist = random.sample(range(0, limit), limit)
    return (randomlist)

def SelectionSort(M):
    for i in range(len(M)):
        min_idx = i
        for j in range(i+1, len(M)):
            if M[min_idx] < M[j]:
                min_idx = j
        M[i], M[min_idx] = M[min_idx], M[i]
        return M

def partition(lst, bawah, atas):
    global count
    i = (bawah - 1)
    pivot = lst[atas]

    for j in range(bawah, atas):
        count += 1
        if lst[j] <= pivot:
            i = i + 1
            lst[i], lst[j] = lst[j], lst[i]

    lst[i + 1], lst[atas] = lst[atas], lst[i + 1]
    return (i + 1)


def quickSort(lst, bawah, atas):
    if bawah < atas:
        pi = partition(lst, bawah, atas)
        quickSort(lst, bawah, pi - 1)
        quickSort(lst, pi + 1, atas)


print("Data setelah diurut:")
for i in reversed(range(1,11)):
    m = 10000 * i
    banyak_data = SelectionSort(random_data(m))
    start_time = time.time()
    quickSort(banyak_data, 0, len(banyak_data) - 1)
    end_time = time.time()
    print('waktu Untuk',m,'data: ',(end_time-start_time))