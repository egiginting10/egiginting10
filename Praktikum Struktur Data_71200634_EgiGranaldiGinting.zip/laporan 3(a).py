class Konversi:
    def __init__(self, isi):
        self.top = -1
        self.isi = isi
        self.stack = []
        self.output = []
        self.precedence = {'+':2, '-':2, '*':3, '/':3, '^':4}
     
    def isEmpty(self):
        if self.top == -1:
            return True
        else:
            return False
     
    def peek(self):
        return self.stack[-1]
     
    def pop(self):
        if not self.isEmpty():
            self.top -= 1
            return self.stack.pop()
        else:
            return "$"
     
    def push(self, masuk):
        self.top += 1
        self.stack.append(masuk)
 
    def isOperand(self, ch):
        return ch.isalpha()
 
    def notGreater(self, i):
        try:
            a = self.precedence[i]
            b = self.precedence[self.peek()]
            if a  <= b:
                return True 
            else:
                 False
        except KeyError:
            return False
             
    def infixToPostfix(self, exp):
        
        for i in exp:
            if self.isOperand(i):
                self.output.append(i)            
            if i  == '(':
                self.push(i)
            if i == ')':
                while( (not self.isEmpty()) and
                                self.peek() != '('):
                    a = self.pop()
                    self.output.append(a)
                if (not self.isEmpty() and self.peek() != '('):
                    return -1
                else:
                    self.pop()
            else:
                while(not self.isEmpty() and self.notGreater(i)):
                    self.output.append(self.pop())
                self.push(i)
        while not self.isEmpty():
            self.output.append(self.pop())
 
        print ("".join(self.output))
exp = 'A+B'
obj = Konversi(len(exp))
obj.infixToPostfix(exp)